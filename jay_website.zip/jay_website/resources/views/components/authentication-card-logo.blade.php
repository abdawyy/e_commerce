<a href="/">
    <a class="navbar-brand" href="/"><img src={{ asset('assets/img/logo.jpg') }} alt=""
        style="width: 200px;"></a>
</a>

