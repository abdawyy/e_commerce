<script src={{ asset("assets/js/bootstrap.bundle.min.js")}}></script>
<script src={{ asset("assets/js/main.js")}}></script>
<!-- Toastify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.css">

<!-- Toastify JS -->
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
