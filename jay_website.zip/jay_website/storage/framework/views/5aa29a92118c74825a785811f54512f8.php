<a href="/">
    <a class="navbar-brand" href="/"><img src=<?php echo e(asset('assets/img/logo.jpg')); ?> alt=""
        style="width: 200px;"></a>
</a>

<?php /**PATH C:\e_commerce\jay_website\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>