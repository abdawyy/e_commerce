<?php if (isset($component)) { $__componentOriginal5214b438fcc0cb574166d38dd3f20dce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce = $attributes; } ?>
<?php $component = App\View\Components\Web\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $attributes = $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $component = $__componentOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal498fc9e12fb124779aef755b8ec9c48b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b = $attributes; } ?>
<?php $component = App\View\Components\Web\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $attributes = $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $component = $__componentOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal97320d02efa37e0c3b14170244c3aa23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97320d02efa37e0c3b14170244c3aa23 = $attributes; } ?>
<?php $component = App\View\Components\Web\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $attributes = $__attributesOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $component = $__componentOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__componentOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation with Background Overlay</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        /* Inline styles to mimic the CSS */
        .hero {
            position: relative;
            background-image: url(<?php echo e(asset('assets/img/p-white-t-shirt-2-hero.jpeg')); ?>); /* Your image path */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            width: 100%;
            border-radius: 10px; /* Mimics --border-radius */
            aspect-ratio: 6/3; /* Maintains the aspect ratio */
        }

        /* Overlay effect */
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.386);
            border-radius: 10px; /* Mimics --border-radius */
            transition: background-color 0.3s ease;
            z-index: 1;
        }

        .hero:hover .overlay {
            background-color: rgba(0, 0, 0, 0.23); /* Darkens on hover */
        }

        .card-content {
            position: relative;
            z-index: 2;
            color: white; /* Ensures text is visible over the overlay */
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <div id="home" class="hero d-flex justify-content-center align-items-center">
        <!-- Overlay Div for Background Effect -->
        <div class="overlay"></div>

        <!-- Card Content -->
        <div class="card card-content bg-transparent text-center p-4">
            <h2>Order Confirmation</h2>
            <p>Thank you for your order!</p>
            <p>Your Order ID: <strong>#<?php echo e($orderID); ?></strong></p>
            <p>Delivery fees: <strong>#<?php echo e($deleveryFees); ?></strong></p>

            <p>Total Price: <strong><?php echo e($totalPrice); ?> LE </strong></p>
            <a href="/" class="btn btn-primary mt-3">Back to Home</a>
        </div>
    </div>

    <!-- Bootstrap JS (Optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php if (isset($component)) { $__componentOriginalcb202c51f5688fc06368e1ddd94a426e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e = $attributes; } ?>
<?php $component = App\View\Components\Web\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $attributes = $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $component = $__componentOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php /**PATH C:\e_commerce\jay_website\resources\views/checkout/receipt.blade.php ENDPATH**/ ?>