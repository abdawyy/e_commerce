<?php if (isset($component)) { $__componentOriginal5214b438fcc0cb574166d38dd3f20dce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce = $attributes; } ?>
<?php $component = App\View\Components\Web\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $attributes = $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $component = $__componentOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal498fc9e12fb124779aef755b8ec9c48b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b = $attributes; } ?>
<?php $component = App\View\Components\Web\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $attributes = $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $component = $__componentOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal97320d02efa37e0c3b14170244c3aa23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97320d02efa37e0c3b14170244c3aa23 = $attributes; } ?>
<?php $component = App\View\Components\Web\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $attributes = $__attributesOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $component = $__componentOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__componentOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>

<style>
svg{
    display: none;
}



</style>
<section class="pb-5">
    <div class="container py-5">
        <div class="row">
            <!-- Sidebar for Filters (Only visible on large screens) -->
            <div class="col-lg-3 col-8 position-relative d-none d-lg-block">
                <aside class="position-sticky" style="top: 100px;">
                    <div class="card card-aside">
                        <div class="card-body">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5>Filter</h5>
                                        <i class="fa-solid fa-filter"></i>
                                    </div>
                                    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist"
                                        aria-orientation="vertical">
                                        <!-- Example dynamic categories (T-shirt, Tops) -->
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="text-start nav-link <?php echo e($loop->first ? '' : ''); ?>"
                                                data-bs-target="#v-pills-<?php echo e($category->id); ?>" role="tab"
                                                href="/product/list/category/<?php echo e($category->id); ?>"
                                                aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                                                <?php echo e($category->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>

            <!-- Main product listing -->
            <main class="col-lg-9 col-12" id="allProduct">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <?php if(!$id): ?>
                    <h1 class="fs-1 mb-0 pb-0">ALL PRODUCTS</h1>
                    <?php else: ?>
                    <h1 class="fs-1 mb-0 pb-0"><?php echo e($categoryName->name); ?></h1>
                    <?php endif; ?>

                    <!-- Mobile filter dropdown -->
                    <div class="dropdown d-lg-none d-block">
                        <button class="dropdownBtn dropdown-toggle px-3" type="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Filter
                        </button>
                        <div class="dropdown-menu" style="width: 200px;">
                            <div class="row p-2">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5>Filter</h5>
                                                <i class="fa-solid fa-filter"></i>
                                            </div>
                                            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist"
                                                aria-orientation="vertical">
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a class="text-start nav-link <?php echo e($loop->first ? '' : ''); ?>"
                                                        data-bs-target="#v-pills-<?php echo e($category->id); ?>" type="button"
                                                        role="tab" href="/product/list/category/<?php echo e($category->id); ?>"
                                                        aria-controls="v-pills-<?php echo e($category->id); ?>"
                                                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                                                        <?php echo e($category->name); ?>

                                                    </a>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab content for product listing based on categories -->
                <div class="tab-content" id="v-pills-tabContent">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade show <?php echo e($loop->first ? 'active' : ''); ?>"
                            id="v-pills-<?php echo e($category->id); ?>" role="tabpanel"
                            aria-labelledby="v-pills-<?php echo e($category->id); ?>-tab" tabindex="0">
                            <div class="row">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-lg-4 pointer mb-3">
                                        <div class="card position-relative">
                                            <a href="<?php echo e(route('product.show', $product->id)); ?>">
                                                <img src="<?php echo e($product->productImages->isNotEmpty() ? Storage::url($product->productImages->first()->images) : asset('assets/img/default-product.jpg')); ?>"
                                                    class="img-fluid" alt="<?php echo e($product->name); ?>">

                                                <div class="card-body pt-2">
                                                    <h5 class="fc-black card-title text-truncate mb-0">
                                                        <?php echo e($product->name); ?>

                                                    </h5>
                                                    <p class="card-text text-truncate my-lg-1 my-0 fc-gray">
                                                        <?php echo e($product->description); ?>

                                                    </p>
                                                    <p class="fc-black fw-bolder text-truncate fs-6 mb-0">
                                                        <?php if($product->sale): ?> <!-- Check if sale is active -->
                                                            <span class="text-decoration-line-through text-muted me-2">
                                                                <?php echo e(number_format($product->price, 2)); ?> LE
                                                            </span>
                                                            <span class="text-danger">
                                                                <?php echo e(number_format($product->price - ($product->price * $product->sale / 100), 2)); ?> LE
                                                            </span>
                                                        <?php else: ?>
                                                            <?php echo e(number_format($product->price, 2)); ?> LE
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </a>
                                            <div class="cart">
                                                <img src="<?php echo e(asset('assets/img/cart.svg')); ?>"
                                                    style="width: 24px; object-fit: scale-down;" alt="Add to cart">
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-end">
                    <nav aria-label="Page navigation example">
                        <div class="d-flex align-items-center gap-2">
                            <div class="icon-Previous me-1">
                                <i class="fa-solid fa-chevron-left"></i>
                            </div>
                            <div class="page-number d-flex align-items-center gap-1">
                                <!-- Example pagination links -->
                                <?php echo e($data->links()); ?>

                            </div>
                            <div class="icon-Next ms-1">
                                <i class="fa-solid fa-chevron-right"></i>
                            </div>
                        </div>
                    </nav>
                </div>
            </main>
        </div>
    </div>
</section>
<?php if (isset($component)) { $__componentOriginalcb202c51f5688fc06368e1ddd94a426e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e = $attributes; } ?>
<?php $component = App\View\Components\Web\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $attributes = $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $component = $__componentOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php /**PATH C:\e_commerce\jay_website\resources\views/product/list.blade.php ENDPATH**/ ?>