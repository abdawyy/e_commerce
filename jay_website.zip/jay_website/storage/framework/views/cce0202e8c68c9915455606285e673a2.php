<script src=<?php echo e(asset("assets/js/bootstrap.bundle.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/js/main.js")); ?>></script>
<!-- Toastify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.css">

<!-- Toastify JS -->
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<?php /**PATH C:\e_commerce\jay_website\resources\views/components/web/footer.blade.php ENDPATH**/ ?>