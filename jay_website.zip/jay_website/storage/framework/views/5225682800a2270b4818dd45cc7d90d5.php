<?php if (isset($component)) { $__componentOriginal5214b438fcc0cb574166d38dd3f20dce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce = $attributes; } ?>
<?php $component = App\View\Components\Web\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $attributes = $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $component = $__componentOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal498fc9e12fb124779aef755b8ec9c48b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b = $attributes; } ?>
<?php $component = App\View\Components\Web\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $attributes = $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $component = $__componentOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal97320d02efa37e0c3b14170244c3aa23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97320d02efa37e0c3b14170244c3aa23 = $attributes; } ?>
<?php $component = App\View\Components\Web\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $attributes = $__attributesOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $component = $__componentOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__componentOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>




<section id="home" class="pt-4 pb-5">
    <div class="container ">
        <div class="hero p-4">
            <div class="row fc-white align-content-end h-100 z-3">
                <div class="row justify-content-between align-items-center">
                    <div class="col-12">
                        <h1 class="fw-bolder">JAY'S BRAND COLLECTION</h1>
                    </div>
                </div>
                <div class="row justify-content-between align-items-center">
                    <div class="col-12 col-lg-7">

                        <p>Discover our latest collection, featuring unique styles that celebrate the vibrant culture
                            and fashion of Egypt</p>
                    </div>
                    <div class="col-12 col-lg-5 text-lg-end text-start">
                        <a href="/product/list/category" class="btn-custom px-5 py-2 fw-bolder">Discover</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="newCollection" class="py-lg-5 pb-5">
    <div class="container">
        <div class="section-title">
            <div class="text-center">
                <h2 class="fw-bolder">NEW COLLECTION</h2>
                <p class="fc-gray fw-semibold">Elevate your style with our new collection, crafted by Jay.</p>
            </div>
            <div class="row py-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-lg-3 pointer mb-3">
                        <div class="card position-relative">
                            <a href="<?php echo e(url('product/show/' . $product->id)); ?>"> <!-- Link to product detail page -->
                                <?php if($product->productImages->isNotEmpty()): ?>
                                    <img src="<?php echo e(asset('storage/' . $product->productImages->first()->images)); ?>"
                                        class="img-fluid" alt="<?php echo e($product->title); ?>">
                                <?php endif; ?>

                                <div class="card-body pt-2">
                                    <h5 class="card-title text-truncate mb-0 fc-black"><?php echo e($product->name); ?></h5>
                                    <!-- Product title -->
                                    <p class="card-text text-truncate my-lg-1 my-0 fc-gray"><?php echo e($product->description); ?>

                                    </p> <!-- Product description -->

                                    <!-- Product price -->
                                    <p class="fc-black fw-bolder text-truncate fs-6 mb-0">
                                        <?php if($product->sale): ?> <!-- Check if sale is active -->
                                            <span class="text-decoration-line-through text-muted me-2">
                                                <?php echo e(number_format($product->price, 2)); ?> LE
                                            </span>
                                            <span class="text-danger">
                                                <?php echo e(number_format($product->price - ($product->price * $product->sale / 100), 2)); ?> LE
                                            </span>
                                        <?php else: ?>
                                            <?php echo e(number_format($product->price, 2)); ?> LE
                                        <?php endif; ?>
                                    </p>

                                </div>
                            </a>
                            <div class="cart">
                                <img src="<?php echo e(asset('assets/img/cart.svg')); ?>"
                                    style="width: 24px; object-fit: scale-down;" alt="Add to cart">
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
            <div class="d-flex justify-content-center">
                <a href="/product/list/category"><button
                        class="btn-custom-dark px-5 py-2 d-flex align-items-center gap-2">Show All <i
                            class="fa-solid fa-arrow-right"></i></button></a>
            </div>
        </div>
    </div>
</section>

<section id="category" class="pb-5">
    <div class="container pb-5">
        <div class="row justify-content-center">
            <div class="col-10 col-lg-4 col-md-6 pb-3">
                <div class="tops p-3">
                    <div class="row align-content-end h-100">
                        <h5 class="fw-bolder fc-white fs-1">Top</h5>
                        <div class="d-flex">
                            <a href="<?php echo e(route('product.List')); ?>"><button class="btn-custom px-5 py-2 fw-bolder">See
                                    Details</button></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-10 col-lg-4 col-md-6 pb-3">
                <div class="t-shirt p-3">
                    <div class="row align-content-end h-100">
                        <h5 class="fw-bolder fc-white fs-1">T-Shirt</h5>
                        <div class="d-flex">
                            <a href="<?php echo e(route('product.List')); ?>"><button class="btn-custom px-5 py-2 fw-bolder">See
                                    Details</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>


<footer class="bg-black text-light">
    <div class="container py-3">
        <div class="row align-items-center justify-content-between">
            <div class="col-12 col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; 2024 Jays's Production</p>
            </div>
            <div class="col-12 col-md-6 pt-md-0 pt-2">
                <div class="d-flex align-items-center gap-4 justify-content-md-end justify-content-center">
                    <a href="" class="text-light">Terms</a>
                    <a href="" class="text-light">Privacy Policy</a>
                    <a href="" class="text-light">Cookie Policy</a>
                </div>

            </div>
        </div>
    </div>
</footer>







<?php if (isset($component)) { $__componentOriginalcb202c51f5688fc06368e1ddd94a426e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e = $attributes; } ?>
<?php $component = App\View\Components\Web\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $attributes = $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $component = $__componentOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php /**PATH C:\e_commerce\jay_website\resources\views/index.blade.php ENDPATH**/ ?>