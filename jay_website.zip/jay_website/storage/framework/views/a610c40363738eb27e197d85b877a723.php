<div class="container">
    <!-- Validation Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Search Form (Right-Aligned) -->
    <form action="<?php echo e(url()->current()); ?>" method="GET" class="mb-3 d-flex justify-content-end">
        <div class="input-group w-25">
            <input type="text" name="search" class="form-control mx-2" placeholder="Search..." value="<?php echo e(request('search')); ?>">
            <button class="btn btn-dark" type="submit">Search</button>
        </div>
    </form>

    <!-- Table -->
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"><?php echo e($header); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php if($rows->isEmpty()): ?>
                    <tr>
                        <td colspan="<?php echo e(count($headers)); ?>" class="text-center">No results found.</td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($row[$header] ?? ''); ?>


                                <?php if($header=='Action'): ?>
                              <a class="btn btn-danger" href="<?php echo e($url); ?>/delete/<?php echo e($row['ID']); ?>">Delete</a>
                              <a class="btn btn-primary" href="<?php echo e($url); ?>/edit/<?php echo e($row['ID']); ?>">View</a>

                            </td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\e_commerce\jay_website\resources\views/components/data-table.blade.php ENDPATH**/ ?>