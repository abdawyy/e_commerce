<?php if (isset($component)) { $__componentOriginal5214b438fcc0cb574166d38dd3f20dce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce = $attributes; } ?>
<?php $component = App\View\Components\Web\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $attributes = $__attributesOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__attributesOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce)): ?>
<?php $component = $__componentOriginal5214b438fcc0cb574166d38dd3f20dce; ?>
<?php unset($__componentOriginal5214b438fcc0cb574166d38dd3f20dce); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal498fc9e12fb124779aef755b8ec9c48b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b = $attributes; } ?>
<?php $component = App\View\Components\Web\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $attributes = $__attributesOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__attributesOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b)): ?>
<?php $component = $__componentOriginal498fc9e12fb124779aef755b8ec9c48b; ?>
<?php unset($__componentOriginal498fc9e12fb124779aef755b8ec9c48b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal97320d02efa37e0c3b14170244c3aa23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97320d02efa37e0c3b14170244c3aa23 = $attributes; } ?>
<?php $component = App\View\Components\Web\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $attributes = $__attributesOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__attributesOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97320d02efa37e0c3b14170244c3aa23)): ?>
<?php $component = $__componentOriginal97320d02efa37e0c3b14170244c3aa23; ?>
<?php unset($__componentOriginal97320d02efa37e0c3b14170244c3aa23); ?>
<?php endif; ?>


<section id="oneProduct" class="pb-5">
    <div class="container py-5">
        <div class="row ">
            <div class="col-12 col-lg-6">
                <div class="row">
                    <!-- Main image -->
                    <div class="col-12 px-2" style="margin-bottom: 12px;">
                        <img id="mainImage" class="img-fluid img-oneProduct pointer"
                            src="<?php echo e($product->productImages->first() ? asset('storage/' . $product->productImages->first()->images) : asset('assets/img/default-image.jpg')); ?>"
                            alt="<?php echo e($product->name); ?>" onclick="openImage(this)">
                    </div>

                    <!-- Thumbnails -->
                    <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3 px-2">
                            <img class="img-fluid img-oneProduct-sub pointer <?php echo e($loop->first ? 'img-selected' : ''); ?>"
                                src="<?php echo e(asset('storage/' . $productImage->images)); ?>" alt="<?php echo e($product->name); ?>"
                                onclick="changeMainImage(this)">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="col-12 col-lg-6 pt-4 pt-lg-0 pb-5">
                <!-- Product stock status -->
                <div class="d-flex pb-3 gap-2">
                    <?php
                    $totalQuantity = $product->productItems->sum('quantity');
                ?>

                <?php if($totalQuantity > 0): ?>
                    <span class="inStock px-3 fw-semibold">In Stock</span>
                <?php else: ?>
                    <span class="outStock px-3 fw-semibold">Out of Stock</span>
                <?php endif; ?>

                </div>

                <!-- Product title and bestseller status -->
                <div class="d-flex justify-content-between align-items-center">
                    <h1 class="fw-semibold fs-3"><?php echo e($product->name); ?></h1>
                    
                </div>

                <!-- Product price -->
                <h2 class="fw-bolder fs-2">
                    <?php if($product->sale): ?>
                        <span class=" mx-3 text-decoration-line-through fw-normal fst-italic fc-gray">
                            <?php echo e($product->price); ?> LE
                              </span>
                        <?php echo e($product->price - ($product->price * $product->sale / 100)); ?> LE
                    <?php else: ?>
                        <?php echo e($product->price); ?> LE
                    <?php endif; ?>
                </h2>


                <!-- Product description -->
                <p class="fs-5 fw-bolder mb-0 pt-2">Description:</p>
                <p class="lh-sm"><?php echo e($product->description); ?></p>

                <!-- Product color -->
                <div class="d-flex gap-2 flex-column">
                    <span class="fs-5 fw-bolder">Color:</span>
                    <div class="d-flex align-items-center gap-2 warp">
                        <input type="radio" class="btn-check" name="color" id="<?php echo e($product->color); ?>"
                            autocomplete="off" checked>
                        <label class="color-checked px-3 py-1 fw-semibold pointer" for="<?php echo e($product->color); ?>">
                            <?php echo e(ucfirst($product->color)); ?>

                        </label>
                    </div>
                </div>

<!-- Quantity section -->
<div class="d-flex gap-2 align-items-center mt-3">
    <span class="fs-5 fw-bolder">Quantity:</span>
    <div class="quantity-control d-flex align-items-center gap-2">
        <button type="button" class="btn btn-outline-secondary" id="decrease-qty" onclick="changeQuantity(-1)">-</button>
        <input type="number" class="form-control text-center" id="quantity" name="quantity" value="1" min="1">
        <button type="button" class="btn btn-outline-secondary" id="increase-qty" onclick="changeQuantity(1)">+</button>
    </div>
</div>
                <!-- Product sizes -->
                <div class="d-flex gap-2 flex-column pt-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <span class="fs-5 fw-bolder">Size:</span>
                        <span class="fs-6 fw-normal pointer" data-bs-toggle="modal" data-bs-target="#sizeModal"
                            style="text-decoration: underline; text-underline-offset: 2px;">What's my size?</span>
                    </div>
                    <div class="d-flex align-items-center gap-2 warp">
                        <?php $__currentLoopData = $product->productItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="radio" class="btn-check" name="productItem_id" id="<?php echo e($productItem->size); ?>"
                                value="<?php echo e($productItem->id); ?>" autocomplete="off"
                                <?php if($productItem->quantity == 0): ?> disabled <?php endif; ?>>
                            <label class="color-checked px-3 py-1 fw-semibold pointer"
                                for="<?php echo e($productItem->size); ?>"
                                style="<?php if($productItem->quantity == 0): ?> opacity: 0.5; <?php endif; ?>">
                                <?php echo e($productItem->size); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <!-- Buy and Add to cart buttons -->
                <div class="row pt-4">
                   
                    <div class="col-5">
                        <button class="outlineBtn w-100 fw-semibold" style="padding: 12px 0px;"
                            onclick="addToCart(<?php echo e($product->id); ?>)">Add to cart</button>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal for size guide -->
    <div class="modal fade" id="sizeModal" tabindex="-1" aria-labelledby="sizeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="sizeModalLabel">What's my size</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <img class="img-fluid" src="<?php echo e(asset('assets/img/whatMySize.png')); ?>" alt="Size Guide">
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    // Get all the radio options
    const radioOptions = document.querySelectorAll('.radio-option input[type="radio"]');

    radioOptions.forEach((radio) => {
        radio.addEventListener('change', function() {
            // Remove the 'active' class from all radio options
            document.querySelectorAll('.radio-option').forEach(option => {
                option.style.borderColor = 'transparent'; // Remove the red border from all
            });

            // Add a red border to the parent radio-option of the checked input
            if (this.checked) {
                this.closest('.radio-option').style.borderColor =
                    'black'; // Apply red border to checked radio
            }
        });
    });



    function changeMainImage(smallImage) {
        const mainImage = document.getElementById('mainImage');
        mainImage.src = smallImage.src;

        // Optional: Add active class to the clicked thumbnail
        const thumbnails = document.querySelectorAll('.img-oneProduct-sub');
        thumbnails.forEach(thumb => thumb.classList.remove('img-selected'));
        smallImage.classList.add('img-selected');
    }

    function openImage(img) {
        // Create a div element for the overlay
        var overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.zIndex = '999999999999';

        // Create an image element to display the clicked image
        var largeImg = document.createElement('img');
        largeImg.src = img.src;
        largeImg.style.maxWidth = '90%';
        largeImg.style.maxHeight = '90%';

        // Add the image to the overlay
        overlay.appendChild(largeImg);

        // Add the overlay to the body
        document.body.appendChild(overlay);

        // Close the overlay when clicking outside the image
        overlay.onclick = function(event) {
            if (event.target === overlay) {
                document.body.removeChild(overlay);
            }
        };
    }
</script>
<?php if (isset($component)) { $__componentOriginalcb202c51f5688fc06368e1ddd94a426e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e = $attributes; } ?>
<?php $component = App\View\Components\Web\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $attributes = $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $component = $__componentOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<script>
function addToCart(productId) {
    let selectedSize = document.querySelector('input[name="productItem_id"]:checked');
    let qtyInput = document.getElementById('quantity');

    if (!selectedSize) {
        alert("Please select a size before adding to cart.");
        return;
    }

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({
            product_id: productId,
            size_id: selectedSize.value,
            quantity: qtyInput.value
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                if (response.status === 401) {
                    Toastify({
                        text: "Unauthorized access! Redirecting to login...",
                        duration: 3000,
                        gravity: "top",
                        position: 'right',
                        backgroundColor: "orange",
                        stopOnFocus: true
                    }).showToast();

                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 3000);
                }
                throw new Error(data.message);
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Update cart count dynamically
            let cartBadge = document.querySelector('.cart-Notify');
            let newCartCount = data.cartCount > 9 ? '+9' : data.cartCount;
            cartBadge.textContent = newCartCount; // Update the cart count badge

            // Show success message
            Toastify({
                text: data.message,
                duration: 3000,
                gravity: "top",
                position: 'right',
                backgroundColor: "green",
                stopOnFocus: true
            }).showToast();
        }
    })
    .catch(error => {
        Toastify({
            text: error.message,
            duration: 3000,
            gravity: "top",
            position: 'right',
            backgroundColor: "red",
            stopOnFocus: true
        }).showToast();
    });
}



    function buyNow(productId) {
        // Get the selected size
        let selectedSize = document.querySelector('input[name="productItem_id"]:checked');

        // Check if a size is selected
        if (!selectedSize) {
            alert("Please select a size before proceeding to checkout.");
            return;
        }

        // Get the selected color

        // Send AJAX request to add product to the cart, then redirect to checkout
        fetch('/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                        'content') // For Laravel CSRF protection
                },
                body: JSON.stringify({
                    product_id: productId,
                    size_id: selectedSize.value,
                    quantity:currentQty

                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success toast notification
                    Toastify({
                        text: data.message,
                        duration: 3000,
                        gravity: "top",
                        position: 'right',
                        backgroundColor: "green",
                        stopOnFocus: true
                    }).showToast();
                } else if (response.status === 401) {
                    // If user is not authenticated, redirect to login page
                    window.location.href = data.redirect;
                }
            })
            .catch(error => console.error('Error:', error));
    }
</script>
<script>
    function changeQuantity(amount) {
        let qtyInput = document.getElementById('quantity');
        let currentQty = parseInt(qtyInput.value);

        // Prevent negative or zero quantities
        if (currentQty + amount > 0) {
            qtyInput.value = currentQty + amount;
        }
    }
</script>
<?php /**PATH C:\e_commerce\jay_website\resources\views/product/show.blade.php ENDPATH**/ ?>