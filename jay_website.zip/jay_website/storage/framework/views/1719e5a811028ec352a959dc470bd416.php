<?php if (isset($component)) { $__componentOriginal45d9cbba1e84739af2366cafaf311004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45d9cbba1e84739af2366cafaf311004 = $attributes; } ?>
<?php $component = App\View\Components\Admin\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45d9cbba1e84739af2366cafaf311004)): ?>
<?php $attributes = $__attributesOriginal45d9cbba1e84739af2366cafaf311004; ?>
<?php unset($__attributesOriginal45d9cbba1e84739af2366cafaf311004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d9cbba1e84739af2366cafaf311004)): ?>
<?php $component = $__componentOriginal45d9cbba1e84739af2366cafaf311004; ?>
<?php unset($__componentOriginal45d9cbba1e84739af2366cafaf311004); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginald417e0638ea790d8a6d32bd501701baa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald417e0638ea790d8a6d32bd501701baa = $attributes; } ?>
<?php $component = App\View\Components\Admin\Aside::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Aside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald417e0638ea790d8a6d32bd501701baa)): ?>
<?php $attributes = $__attributesOriginald417e0638ea790d8a6d32bd501701baa; ?>
<?php unset($__attributesOriginald417e0638ea790d8a6d32bd501701baa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald417e0638ea790d8a6d32bd501701baa)): ?>
<?php $component = $__componentOriginald417e0638ea790d8a6d32bd501701baa; ?>
<?php unset($__componentOriginald417e0638ea790d8a6d32bd501701baa); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal64e2265cfb81aa59d135283195bf883b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64e2265cfb81aa59d135283195bf883b = $attributes; } ?>
<?php $component = App\View\Components\Admin\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64e2265cfb81aa59d135283195bf883b)): ?>
<?php $attributes = $__attributesOriginal64e2265cfb81aa59d135283195bf883b; ?>
<?php unset($__attributesOriginal64e2265cfb81aa59d135283195bf883b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64e2265cfb81aa59d135283195bf883b)): ?>
<?php $component = $__componentOriginal64e2265cfb81aa59d135283195bf883b; ?>
<?php unset($__componentOriginal64e2265cfb81aa59d135283195bf883b); ?>
<?php endif; ?>
<main id="main">
    <div class="container-fluid">
        <div class="row pt-4">
            <div class="col-12">
                


    <?php if (isset($component)) { $__componentOriginal45d9cbba1e84739af2366cafaf311004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45d9cbba1e84739af2366cafaf311004 = $attributes; } ?>
<?php $component = App\View\Components\Admin\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45d9cbba1e84739af2366cafaf311004)): ?>
<?php $attributes = $__attributesOriginal45d9cbba1e84739af2366cafaf311004; ?>
<?php unset($__attributesOriginal45d9cbba1e84739af2366cafaf311004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d9cbba1e84739af2366cafaf311004)): ?>
<?php $component = $__componentOriginal45d9cbba1e84739af2366cafaf311004; ?>
<?php unset($__componentOriginal45d9cbba1e84739af2366cafaf311004); ?>
<?php endif; ?>


                <div class="container">
                    <div class="row">
                        <div class="col-12 text-end">
                            <button id="printButton" class="btn btn-secondary" onclick="printReceipt()">Print
                                Receipt</button>
                        </div>
                    </div>
                    <h1>Order Details</h1>

                    <div class="card mb-3">
                        <div class="card-header">
                            Order #<?php echo e($order->id); ?>

                        </div>
                        <div class="card-body">
                            <p><strong>User:</strong> <?php echo e($order->user->name ?? 'N/A'); ?></p>
                            <p><strong>City:</strong> <?php echo e($order->cities->name ?? 'N/A'); ?></p>
                            <p><strong>Delivery Fees:</strong> <?php echo e($order->cities->price ?? 'N/A'); ?></p>
                            <p><strong>Total Amount:</strong> <?php echo e($order->total_amount ?? 'N/A'); ?> LE</p>


                            <p><strong>Discount Code:</strong> <?php echo e($order->discountCodes->code ?? 'N/A'); ?></p>
                            <p><strong>Order Date:</strong>
                                <?php echo e($order->created_at ? $order->created_at->format('Y-m-d H:i') : 'N/A'); ?></p>
                            <p><strong>Status:</strong> <?php echo e($order->status ?? 'Pending'); ?></p>
                        </div>
                    </div>
                    <h1>Address</h1>

                    <div class="card mb-3">
                        <div class="card-body">
                            <?php if($order->user && $order->user->address->isNotEmpty()): ?>
                                <?php $__currentLoopData = $order->user->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="address-section mb-3">
                                        <p><strong>Address Line 1:</strong> <?php echo e($address->address_line1 ?? 'N/A'); ?></p>
                                        <p><strong>Address Line 2:</strong> <?php echo e($address->address_line2 ?? 'N/A'); ?></p>
                                        <p><strong>City:</strong> <?php echo e($address->city ?? 'N/A'); ?></p>
                                        <p><strong>State:</strong> <?php echo e($address->state ?? 'N/A'); ?></p>
                                        <p><strong>Postal Code:</strong> <?php echo e($address->postal_code ?? 'N/A'); ?></p>
                                        <p><strong>Country:</strong> <?php echo e($address->country ?? 'N/A'); ?></p>
                                        <hr>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p><strong>Address:</strong> N/A</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <h2>Order Items</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product</th>
                                <th>Size</th>

                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->product->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->productItems->size ?? 'N/A'); ?></td>

                                    <td><?php echo e($item->quantity ?? 0); ?></td>
                                    <td><?php echo e($item->price ?? 0); ?> LE</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4">No items found for this order.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <h2>Payments</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__empty_1 = true; $__currentLoopData = $order->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($payment->id); ?></td>
                                    <td><?php echo e($payment->amount ?? 0); ?> LE</td>
                                    <td><?php echo e($payment->created_at ? $payment->created_at->format('Y-m-d H:i') : 'N/A'); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">No payments found for this order.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <form id="form" action="<?php echo e(route('order.changeStatus', $order->id)); ?>" method="POST"
                        class="mt-4">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="status">Change Status:</label>
                            <select name="status" id="status" class="form-control">
                                <option value="Pending" <?php echo e($order->status == 'Pending' ? 'selected' : ''); ?>>Pending
                                </option>
                                <option value="Processing" <?php echo e($order->status == 'Processing' ? 'selected' : ''); ?>>
                                    Processing</option>
                                <option value="Completed" <?php echo e($order->status == 'Completed' ? 'selected' : ''); ?>>
                                    Completed
                                </option>
                                <option value="Cancelled" <?php echo e($order->status == 'Cancelled' ? 'selected' : ''); ?>>
                                    Cancelled
                                </option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Status</button>
                    </form>

                </div>

                <!-- Receipt Section -->
                <div id="receipt" style="display: none;">
                    <h2>Receipt</h2>
                    <p><strong>Order ID:</strong> <span id="receiptOrderId"></span></p>
                    <p><strong>User Name:</strong> <span id="receiptUserName"></span></p>
                    <p><strong>City:</strong> <span id="receiptCity"></span></p>
                    <p><strong>Order Date:</strong> <span id="receiptOrderDate"></span></p>
                    <p><strong>Status:</strong> <span id="receiptOrderStatus"></span></p>
                </div>
            </div>
            <!-- CSS for Print -->
            <style>
                @media print {

                    #navbar,
                    #sidebar,
                    #printButton,
                    #receipt,
                    #form * {
                        visibility: hidden;
                    }

                    #receipt,
                    #receipt * {
                        visibility: visible;
                    }

                    #receipt {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                    }
                }
            </style>

            <!-- JavaScript -->
            <script>
                function generateReceipt() {
                    // Get values from input fields
                    const orderId = document.getElementById('orderId').value;
                    const userName = document.getElementById('userName').value;
                    const city = document.getElementById('city').value;
                    const orderDate = document.getElementById('orderDate').value;
                    const orderStatus = document.getElementById('orderStatus').value;

                    // Populate receipt section
                    document.getElementById('receiptOrderId').textContent = orderId;
                    document.getElementById('receiptUserName').textContent = userName;
                    document.getElementById('receiptCity').textContent = city;
                    document.getElementById('receiptOrderDate').textContent = orderDate;
                    document.getElementById('receiptOrderStatus').textContent = orderStatus;

                    // Show the receipt section
                    document.getElementById('receipt').style.display = 'block';
                }

                function printReceipt() {
                    window.print();
                }
            </script>
            <?php if (isset($component)) { $__componentOriginalcb202c51f5688fc06368e1ddd94a426e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e = $attributes; } ?>
<?php $component = App\View\Components\Web\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Web\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $attributes = $__attributesOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__attributesOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e)): ?>
<?php $component = $__componentOriginalcb202c51f5688fc06368e1ddd94a426e; ?>
<?php unset($__componentOriginalcb202c51f5688fc06368e1ddd94a426e); ?>
<?php endif; ?>
<?php /**PATH C:\e_commerce\jay_website\resources\views/admin/order/show.blade.php ENDPATH**/ ?>