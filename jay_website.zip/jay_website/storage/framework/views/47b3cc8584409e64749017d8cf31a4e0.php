<script src=<?php echo e(asset("admin/assets/js/bootstrap.bundle.min.js")); ?>></script>
    <script src=<?php echo e(asset("admin/assets/js/main-Dashboard.js")); ?>></script>
<?php /**PATH C:\e_commerce\jay_website\resources\views/components/admin/footer.blade.php ENDPATH**/ ?>